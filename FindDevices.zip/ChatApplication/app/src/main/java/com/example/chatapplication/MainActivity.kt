package com.example.chatapplication


import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.location.LocationManager
import android.os.Bundle
import android.provider.Settings
import android.util.Log
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ImageView
import android.widget.ListView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import com.example.chatapplication.databinding.ActivityMainBinding
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin


class MainActivity : AppCompatActivity() {
    private lateinit var btnON: Button
    private lateinit var btnOFF: Button
    private lateinit var btnPaired: Button
    private lateinit var bt_list : ListView
    private lateinit var locationButton: Button

    private lateinit var binding: ActivityMainBinding
    private lateinit var deviceListAdapter: ArrayAdapter<String>
    private lateinit var bluetoothAdapter: BluetoothAdapter
    private val REQUEST_ENABLE_BT = 1
    private val REQUEST_CODE_LOCATION_PERMISSION = 1001

    // Add necessary variables for location estimation and bitmap display
    private lateinit var imageid: ImageView
    private lateinit var bitmap: Bitmap
    private val deviceCoordinates = mutableMapOf<BluetoothDevice, Pair<Double, Double>>()

    @SuppressLint("MissingPermission")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        btnON = findViewById(R.id.btnON)
        btnOFF = findViewById(R.id.btnOFF)
        btnPaired = findViewById(R.id.btnPaired)
        bt_list = findViewById(R.id.bt_list)
        locationButton = findViewById(R.id.locationButton)
        imageid = findViewById(R.id.imageid)



     //   var bt_list = findViewById <ListView>(R.id.bt_list)




        val bluetoothManager = getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothAdapter = bluetoothManager.adapter
        deviceListAdapter = ArrayAdapter(this, android.R.layout.simple_list_item_1)
        bt_list.adapter = deviceListAdapter

        // Initialize the ImageView and Bitmap
        bitmap = Bitmap.createBitmap(500, 400, Bitmap.Config.ARGB_8888)
        imageid.setImageBitmap(bitmap)




        binding.btnOFF.setOnClickListener(View.OnClickListener{
            bluetoothAdapter.disable()

        })
        binding.btnON.setOnClickListener(View.OnClickListener{
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivityForResult(enableBtIntent, REQUEST_ENABLE_BT)

        })
        binding.btnPaired.setOnClickListener(View.OnClickListener {
            val locationManager = getSystemService(Context.LOCATION_SERVICE) as LocationManager
            if (locationManager.isProviderEnabled(LocationManager.GPS_PROVIDER) ||
                locationManager.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {

                val discoveryStarted = bluetoothAdapter.startDiscovery()
                if (discoveryStarted) {
                    Toast.makeText(applicationContext, "Scanning for nearby devices...", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(applicationContext, "Failed to start scanning, PLEASE open bluetooth", Toast.LENGTH_SHORT).show()
                }
            } else {
                Toast.makeText(applicationContext, "Location is not enabled", Toast.LENGTH_SHORT).show()
                val enableLocationIntent = Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS)
                startActivity(enableLocationIntent)

            }
        })


        // Register the BroadcastReceiver
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val action: String? = intent.action
                when (action) {
                    BluetoothDevice.ACTION_FOUND -> {
                        // A Bluetooth device was found
                        val device: BluetoothDevice? = intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                        val rssi: Int = intent.getShortExtra(BluetoothDevice.EXTRA_RSSI, Short.MIN_VALUE).toInt()
                        device?.let {
                            // Add the device to the list
                            val deviceName = device.name ?: "Unknown Device"
                            val deviceAddress = device.address
                            val deviceInfo = "$deviceName\n$deviceAddress\nRSSI: $rssi dBm"
                            deviceListAdapter.add(deviceInfo)

                            // Estimate the device's location using the RSSI value
                            val distance = calculateDistance(rssi)
                            updateDeviceLocation(device, distance)
                            Log.d("Bluetooth", "Device found: $deviceInfo, Distance: $distance")
                        }
                    }
                    BluetoothAdapter.ACTION_DISCOVERY_FINISHED -> {
                        // Scanning finished
                        Toast.makeText(context, "Scanning finished", Toast.LENGTH_SHORT).show()
                        updateBitmap() // Ensure updateBitmap is called after discovery finishes
                    }
                }
            }
        }
        // Register the BroadcastReceiver
        val filter = IntentFilter().apply {
            addAction(BluetoothDevice.ACTION_FOUND)
            addAction(BluetoothAdapter.ACTION_DISCOVERY_FINISHED)
        }
        registerReceiver(receiver, filter)
        // Handle the locationButton click to display devices on bitmap
        locationButton.setOnClickListener {
            updateBitmap()
        }

    }
    private fun calculateDistance(rssi: Int): Double {
        val txPower = -98// Replace with the transmit power of your beacon
        return 10.0.pow((txPower - rssi) / (10 * 2.0))
    }

    private fun updateDeviceLocation(device: BluetoothDevice, distance: Double) {
        // Assuming the grid size is 100x100 pixels
        val gridSize = 450.0
        val angle = 45.0
        val x = (gridSize / 2) + ((distance * cos(Math.toRadians(angle))) * gridSize / 2)
        val y = (gridSize / 2) + ((distance * sin(Math.toRadians(angle))) * gridSize / 2)
        deviceCoordinates[device] = Pair(x, y)

    }

    private fun updateBitmap() {
        // Clear the bitmap
        bitmap.eraseColor(Color.WHITE)

        // Draw the grid lines
        val canvas = Canvas(bitmap)
        val linePaint = Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 2f
        }

        // Calculate the grid cell width and height
        val cellWidth = bitmap.width / 3f
        val cellHeight = bitmap.height / 3f

        // Draw horizontal lines
        canvas.drawLine(0f, cellHeight, bitmap.width.toFloat(), cellHeight, linePaint)
        canvas.drawLine(0f, cellHeight * 2, bitmap.width.toFloat(), cellHeight * 2, linePaint)

        // Draw vertical lines
        canvas.drawLine(cellWidth, 0f, cellWidth, bitmap.height.toFloat(), linePaint)
        canvas.drawLine(cellWidth * 2, 0f, cellWidth * 2, bitmap.height.toFloat(), linePaint)

        // Draw the device locations on the bitmap
        val centerPaint = Paint().apply {
            color = Color.BLUE
            style = Paint.Style.FILL
        }
        val devicePaint = Paint().apply {
            color = Color.RED
            style = Paint.Style.FILL
        }

        // Calculate the center of the bitmap
        val centerX = bitmap.width / 2f
        val centerY = bitmap.height / 2f

        // Draw the blue circle (device) at the center
        canvas.drawCircle(centerX, centerY, 10f, centerPaint)

        // Draw a pink outline around the bitmap
        val outlinePaint = Paint().apply {
            color = Color.rgb(255, 105, 180) // Pink color
            strokeWidth = 10f
            style = Paint.Style.STROKE
        }
        canvas.drawRect(0f, 0f, bitmap.width.toFloat(), bitmap.height.toFloat(), outlinePaint)

        // Sort devices by distance from the center
        val sortedDevices = deviceCoordinates.toList().sortedBy { (_, location) ->
            calculateDistance(centerX.toInt(), centerY.toInt(), location.first.toInt(), location.second.toInt())
        }.toMap()

        // Draw the devices sorted by distance
        for ((device, location) in sortedDevices) {
            canvas.drawCircle(location.first.toFloat(), location.second.toFloat(), 5f, devicePaint)
        }

        // Update the ImageView
        imageid.setImageBitmap(bitmap)
        imageid.invalidate() // Force the ImageView to redraw
    }

    private fun calculateDistance(x1: Int, y1: Int, x2: Int, y2: Int): Double {
        // Calculate distance between two points
        return Math.sqrt(Math.pow((x2 - x1).toDouble(), 2.0) + Math.pow((y2 - y1).toDouble(), 2.0))
    }

    private fun startBluetoothScan() {
        TODO("Not yet implemented")
    }


}